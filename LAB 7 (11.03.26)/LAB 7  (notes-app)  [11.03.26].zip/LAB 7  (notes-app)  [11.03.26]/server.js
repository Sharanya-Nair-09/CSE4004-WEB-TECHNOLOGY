const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const cors = require("cors");

const app = express();

app.use(cors());
app.use(bodyParser.json());
app.use(express.static("public"));

/* MongoDB Connection */

mongoose.connect("mongodb://127.0.0.1:27017/study_notes");

/* Schema */

const NoteSchema = new mongoose.Schema({
title:String,
subject:String,
description:String,
created_date:{
type:Date,
default:Date.now
}
});

const Note = mongoose.model("Note",NoteSchema);

/* ADD NOTE */

app.post("/notes", async (req,res)=>{

const note = new Note({
title:req.body.title,
subject:req.body.subject,
description:req.body.description
});

await note.save();

res.json({message:"Note added"});

});

/* VIEW NOTES */

app.get("/notes", async (req,res)=>{

const notes = await Note.find();

res.json(notes);

});

/* UPDATE NOTE */

app.put("/notes/:id", async (req,res)=>{

await Note.findByIdAndUpdate(req.params.id,{
title:req.body.title,
description:req.body.description
});

res.json({message:"Note updated"});

});

/* DELETE NOTE */

app.delete("/notes/:id", async (req,res)=>{

await Note.findByIdAndDelete(req.params.id);

res.json({message:"Note deleted"});

});

app.listen(3000,()=>{
console.log("Server running on http://localhost:3000");
});