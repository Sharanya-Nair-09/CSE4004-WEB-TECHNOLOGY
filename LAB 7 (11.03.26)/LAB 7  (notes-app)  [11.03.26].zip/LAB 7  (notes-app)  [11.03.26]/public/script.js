const api = "http://localhost:3000/notes";

let currentEditId = null;

/* ADD NOTE */

function addNote(){

const title = document.getElementById("title").value;
const subject = document.getElementById("subject").value;
const description = document.getElementById("description").value;

fetch(api,{
method:"POST",
headers:{
"Content-Type":"application/json"
},
body:JSON.stringify({
title,
subject,
description
})
})
.then(()=>{
clearForm();
loadNotes();
});

}

/* LOAD NOTES */

function loadNotes(){

fetch(api)
.then(res=>res.json())
.then(data=>{

const notesDiv = document.getElementById("notes");

notesDiv.innerHTML="";

data.forEach(note=>{

notesDiv.innerHTML += `
<div class="note-card">

<h3>${note.title}</h3>

<p class="subject">${note.subject}</p>

<p>${note.description}</p>

<div class="buttons">

<button onclick="openEdit('${note._id}','${note.title}','${note.description}')">Edit</button>

<button class="delete" onclick="deleteNote('${note._id}')">Delete</button>

</div>

</div>
`;

});

});

}

/* DELETE */

function deleteNote(id){

fetch(api+"/"+id,{
method:"DELETE"
})
.then(()=>loadNotes());

}

/* OPEN EDIT MODAL */

function openEdit(id,title,description){

currentEditId = id;

document.getElementById("editTitle").value = title;

document.getElementById("editDescription").value = description;

document.getElementById("editModal").style.display="flex";

}

/* CLOSE MODAL */

function closeModal(){

document.getElementById("editModal").style.display="none";

}

/* UPDATE NOTE */

function updateNote(){

const title = document.getElementById("editTitle").value;

const description = document.getElementById("editDescription").value;

fetch(api+"/"+currentEditId,{
method:"PUT",
headers:{
"Content-Type":"application/json"
},
body:JSON.stringify({
title,
description
})
})
.then(()=>{
closeModal();
loadNotes();
});

}

function clearForm(){

document.getElementById("title").value="";
document.getElementById("subject").value="";
document.getElementById("description").value="";

}

loadNotes();