const express = require("express");
const { MongoClient } = require("mongodb");
const cors = require("cors");
const path = require("path");

const app = express();
app.use(cors());
app.use(express.json());

app.use(express.static("public"));

const url = "mongodb://127.0.0.1:27017";
const client = new MongoClient(url);
let db;

async function connectDB() {
    await client.connect();
    db = client.db("bookfinder");
    console.log("MongoDB Connected");
}

connectDB();


// SEARCH BOOK BY TITLE
app.get("/books/search", async (req, res) => {
    const title = req.query.title;

    const books = await db.collection("books")
        .find({ title: { $regex: title, $options: "i" } })
        .toArray();

    res.json(books);
});


// FILTER BY CATEGORY
app.get("/books/category/:category", async (req, res) => {

    const category = req.params.category;

    const books = await db.collection("books")
        .find({ category: category })
        .toArray();

    res.json(books);
});


// SORT BOOKS
app.get("/books/sort/:type", async (req, res) => {

    const type = req.params.type;

    let sortOption = {};

    if (type === "price") sortOption = { price: 1 };
    if (type === "rating") sortOption = { rating: -1 };

    const books = await db.collection("books")
        .find()
        .sort(sortOption)
        .toArray();

    res.json(books);
});


// TOP RATED
app.get("/books/top", async (req, res) => {

    const books = await db.collection("books")
        .find({ rating: { $gte: 4 } })
        .limit(5)
        .toArray();

    res.json(books);
});


// PAGINATION
app.get("/books", async (req, res) => {

    const page = parseInt(req.query.page) || 1;
    const limit = 5;

    const books = await db.collection("books")
        .find()
        .skip((page - 1) * limit)
        .limit(limit)
        .toArray();

    res.json(books);
});


app.listen(3000, () => {
    console.log("Server running on http://localhost:3000");
});