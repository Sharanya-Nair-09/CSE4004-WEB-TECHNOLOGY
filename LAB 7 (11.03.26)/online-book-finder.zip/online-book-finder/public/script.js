
let page = 1;

async function loadBooks(){

const res = await fetch(`/books?page=${page}`);
const data = await res.json();

displayBooks(data);

}

function displayBooks(books){

const container = document.getElementById("bookList");

books.forEach(book=>{

const div = document.createElement("div");

div.className="book";

div.innerHTML=`
<h3>${book.title}</h3>
<p>Author: ${book.author}</p>
<p>Category: ${book.category}</p>
<p>Price: ₹${book.price}</p>
<p>Rating: ⭐ ${book.rating}</p>
`;

container.appendChild(div);

});

}


async function searchBooks(){

const title = document.getElementById("search").value;

const res = await fetch(`/books/search?title=${title}`);
const data = await res.json();

document.getElementById("bookList").innerHTML="";
displayBooks(data);

}

async function filterCategory(){

const cat = document.getElementById("category").value;

const res = await fetch(`/books/category/${cat}`);
const data = await res.json();

document.getElementById("bookList").innerHTML="";
displayBooks(data);

}

async function sortPrice(){

const res = await fetch(`/books/sort/price`);
const data = await res.json();

document.getElementById("bookList").innerHTML="";
displayBooks(data);

}

async function sortRating(){

const res = await fetch(`/books/sort/rating`);
const data = await res.json();

document.getElementById("bookList").innerHTML="";
displayBooks(data);

}

async function topBooks(){

const res = await fetch(`/books/top`);
const data = await res.json();

document.getElementById("bookList").innerHTML="";
displayBooks(data);

}

function loadMore(){

page++;
loadBooks();

}

loadBooks();